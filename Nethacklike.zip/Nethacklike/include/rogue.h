#ifndef ROGUE_H
#define ROGUE_H

#include <ncurses.h>
#include <stdlib.h>
#include <time.h>

typedef struct Position {

  int x;
  int y;
  // TILE_TYPE tile;
} Position;

/* makes the player structure */
typedef struct Player
{
  Position position;
  int level;
  int hp;
  int maxhp;
  int b_strength;
  int b_dexterity;
  int b_constitution;
  int b_intelligence;
  int b_wisdom;
  int b_charisma;
  int strength;
  int dexterity;
  int constitution;
  int intelligence;
  int wisdom;
  int charisma;
  int strMod;
  int dexMod;
  int conMod;
  int intMod;
  int wisMod;
  int chaMod;
  int ac;
  int gold;
  int class;
  int race;
  int alignment;
} Player;

int screenSetUp();
int screenClear();
int mapSetUp();

char ** saveLevelPositions();

Player * playerSetUp();
Position * handleInput(int input, Player * user);
int checkPosition(Position * newPosition, Player * user, char ** level);
int playerMove(Position * newPosition, Player * user, char ** level);

#endif
