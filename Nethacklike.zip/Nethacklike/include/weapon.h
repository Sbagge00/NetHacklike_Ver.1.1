#ifndef WEAPON_H
#define WEAPON_H

typedef enum { SWORD_TYPE, SPEAR_TYPE}

typedef struct Weapon
{
    WeaponType type;
    int attack;
}

#endif
