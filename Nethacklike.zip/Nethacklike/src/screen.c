#include "rogue.h"

//clears the screen by printing spaces

int screenClear()
{
  mvprintw(1, 1, "                                                                                                 ");
  mvprintw(2, 1, "                                                                                                 ");
  mvprintw(3, 1, "                                                                                                 ");
  mvprintw(4, 1, "                                                                                                 ");
  mvprintw(5, 1, "                                                                                                 ");
  mvprintw(6, 1, "                                                                                                 ");
  mvprintw(7, 1, "                                                                                                 ");
  mvprintw(8, 1, "                                                                                                 ");
  mvprintw(9, 1, "                                                                                                  ");
  mvprintw(10, 1, "                                                                                                    ");
  mvprintw(11, 1, "                                                                                                    ");
  mvprintw(12, 1, "                                                                                                    ");
  mvprintw(13, 1, "                                                                                                    ");
  mvprintw(14, 1, "                                                                                                    ");
  mvprintw(15, 1, "                                                                                                   ");
  mvprintw(16, 1, "                                                                                                   ");

}


int screenSetUp()
{
  initscr();

    keypad(stdscr, TRUE);

  mvprintw(2, 6, "Time is running out. The cult of the unseen eye has power unstoppable.");
  mvprintw(3, 6, "Power to awaken the ancient one from their slumber. The last day has fallen and");
  mvprintw(4, 6, "darkness covers the land. People cry out for a savior.");

  start_color();
  init_pair(1,COLOR_CYAN, COLOR_BLACK);
  attron(COLOR_PAIR(1));
    mvprintw(6, 6, "                                                                   ORION, the Master Sword");
  attroff(COLOR_PAIR(1));

  mvprintw(6, 6, "Legend speaks of a magical artifact lost to the annals of history.");

  mvprintw(7, 6, "A group of mighty warriors untie to find this artifact and stop the cult from achieving");
  mvprintw(8, 6, "their goal.");

  mvprintw(10, 6, "You have been tasked by this group to investigate a dungeon rumored to hold this mighty");
  mvprintw(11, 6, "weapon.");

  mvprintw(13, 6, "The clouds above you reveal a blue moon as you make your way to the dungeon entrance. ");
  mvprintw(14, 6, "The howls of lost souls fill the night as you find a graveyard and stone chapel.");

  mvprintw(16, 6, "Your time has come, adventurer! Now go forth with the hope of all people!");


  getch();

  screenClear();
  mvprintw(0, 0, "");

  noecho();
  refresh();

  return 0;
}
