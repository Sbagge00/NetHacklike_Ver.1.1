#include "rogue.h"
#include "windows/mainMenu.h"

void menuLoop()
{
    int choice;
    char * choices[] = {"Start Game", "End Game"};

    while (true)
    {
        choice = mainMenu(2, choices);

        switch (choice)
        {
            case START_GAME:
                menuLoop();
                clear();
                break;
            case QUIT_GAME:
                return;
                break;
        }
    }
}

int main ()
{
  Player * user;
  int ch;
  Position * newPosition;

  char ** level;

  screenSetUp();

  char * choices[] = {"Start Game", "End Game:"};

  mainMenu(2, choices);

  mapSetUp();

  level = saveLevelPositions();

  user = playerSetUp();

/* main game loop */
  while ((ch = getch()) != 'Q')
  {
      newPosition = handleInput(ch, user);
      checkPosition(newPosition, user, level);

  }
  endwin();

  return 0;
}
