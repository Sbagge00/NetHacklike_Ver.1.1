#include "rogue.h"

Player * playerSetUp()
{
  Player * newPlayer;
  newPlayer = malloc(sizeof(Player));

  newPlayer->position.x = 15;
  newPlayer->position.y = 15;

  //races
  newPlayer->race = 3;
  /*  1 Orc
      2 Dragonborn
      3 Dwarf
      4 Elf
      5 Gith
      6 Hobbit
      7 Human       */

  // class level
  newPlayer->level = 2;

  // class
  newPlayer->class = 2;
  /*  1 Barbaruan
      2 Cleric
      3 Fighter
      4 Paladin
      5 Rogue
      6 Sorcerer
      7 Wizard     */


  newPlayer->gold = 0;

  // alignment

  if (newPlayer->race == 1) {
    newPlayer->alignment = 1;
  }

  if (newPlayer->race == 2) {
    newPlayer->alignment = 2;
  }

  if (newPlayer->race == 3) {
    newPlayer->alignment = 2;
  }

  if (newPlayer->race == 4) {
    newPlayer->alignment = 1;
  }

  if (newPlayer->race == 5) {
    newPlayer->alignment = 2;
  }

  if (newPlayer->race == 6) {
    newPlayer->alignment = 2;
  }

  if (newPlayer->race == 7) {
    newPlayer->alignment = 0;
  }

  // if player is a Barbarian
  if (newPlayer->class == 1) {
    newPlayer->b_strength = 16;
    newPlayer->b_dexterity = 13;
    newPlayer->b_constitution = 14;
    newPlayer->b_intelligence = 10;
    newPlayer->b_wisdom = 12;
    newPlayer->b_charisma = 10;
  }

  // if player is a Cleric
  if (newPlayer->class == 2) {
    newPlayer->b_strength = 14;
    newPlayer->b_dexterity = 10;
    newPlayer->b_constitution = 13;
    newPlayer->b_intelligence = 10;
    newPlayer->b_wisdom = 15;
    newPlayer->b_charisma = 12;
  }

  // if player is a Fighter
  if (newPlayer->class == 3) {
    newPlayer->b_strength = 15;
    newPlayer->b_dexterity = 15;
    newPlayer->b_constitution = 13;
    newPlayer->b_intelligence = 10;
    newPlayer->b_wisdom = 12;
    newPlayer->b_charisma = 10;
  }

  // if player is a Paladin
  if (newPlayer->class == 4) {
    newPlayer->b_strength = 15;
    newPlayer->b_dexterity = 10;
    newPlayer->b_constitution = 13;
    newPlayer->b_intelligence = 10;
    newPlayer->b_wisdom = 12;
    newPlayer->b_charisma = 14;
  }

  // if player is a Rogue
  if (newPlayer->class == 5) {
    newPlayer->b_strength = 10;
    newPlayer->b_dexterity = 16;
    newPlayer->b_constitution = 10;
    newPlayer->b_intelligence = 13;
    newPlayer->b_wisdom = 12;
    newPlayer->b_charisma = 14;
  }

  // if player is a Wizard
  if (newPlayer->class == 6) {
    newPlayer->b_strength = 10;
    newPlayer->b_dexterity = 13;
    newPlayer->b_constitution = 14;
    newPlayer->b_intelligence = 16;
    newPlayer->b_wisdom = 12;
    newPlayer->b_charisma = 10;
  }

  // if player is a Sorcerer
  if (newPlayer->class == 7) {
    newPlayer->b_strength = 10;
    newPlayer->b_dexterity = 13;
    newPlayer->b_constitution = 14;
    newPlayer->b_intelligence = 10;
    newPlayer->b_wisdom = 12;
    newPlayer->b_charisma = 15;
  }

    // if player is a Orc
      if (newPlayer->race == 1) {
        newPlayer->strength = newPlayer->b_strength + 2;
        newPlayer->dexterity = newPlayer->b_dexterity;
        newPlayer->constitution = newPlayer->b_constitution + 2;
        newPlayer->intelligence = newPlayer->b_intelligence - 2;
        newPlayer->wisdom = newPlayer->b_wisdom;
        newPlayer->charisma = newPlayer->b_charisma;
      }

    // if player is a Dragonborn
      if (newPlayer->race == 2) {
        newPlayer->strength = newPlayer->b_strength + 2;
        newPlayer->dexterity = newPlayer->b_dexterity;
        newPlayer->constitution = newPlayer->b_constitution;
        newPlayer->intelligence = newPlayer->b_intelligence;
        newPlayer->wisdom = newPlayer->b_wisdom;
        newPlayer->charisma = newPlayer->b_charisma + 1;
      }

      // if player is a Dwarf
        if (newPlayer->race == 3) {
        newPlayer->strength = newPlayer->b_strength;
        newPlayer->dexterity = newPlayer->b_dexterity;
        newPlayer->constitution = newPlayer->b_constitution + 2;
        newPlayer->intelligence = newPlayer->b_intelligence;
        newPlayer->wisdom = newPlayer->b_wisdom + 1;
        newPlayer->charisma = newPlayer->b_charisma;
      }

      // if player is a Elf
        if (newPlayer->race == 4) {
          newPlayer->strength = newPlayer->b_strength;
          newPlayer->dexterity = newPlayer->b_dexterity + 2;
          newPlayer->constitution = newPlayer->b_constitution;
          newPlayer->intelligence = newPlayer->b_intelligence + 1;
          newPlayer->wisdom = newPlayer->b_wisdom;
          newPlayer->charisma = newPlayer->b_charisma;
        }

      // if player is a Gith
        if (newPlayer->race == 5) {
          newPlayer->strength = newPlayer->b_strength + 1;
          newPlayer->dexterity = newPlayer->b_dexterity;
          newPlayer->constitution = newPlayer->b_constitution;
          newPlayer->intelligence = newPlayer->b_intelligence + 1;
          newPlayer->wisdom = newPlayer->b_wisdom + 1;
          newPlayer->charisma = newPlayer->b_charisma;
        }

        // if player is a Hobbit
          if (newPlayer->race == 6) {
          newPlayer->strength = newPlayer->b_strength;
          newPlayer->dexterity = newPlayer->b_dexterity + 2;
          newPlayer->constitution = newPlayer->b_constitution;
          newPlayer->intelligence = newPlayer->b_intelligence;
          newPlayer->wisdom = newPlayer->b_wisdom;
          newPlayer->charisma = newPlayer->b_charisma + 1;
        }

        // if player is a Human
          if (newPlayer->race == 7) {
          newPlayer->strength = newPlayer->b_strength + 1;
          newPlayer->dexterity = newPlayer->b_dexterity + 1;
          newPlayer->constitution = newPlayer->b_constitution + 1;
          newPlayer->intelligence = newPlayer->b_intelligence + 1;
          newPlayer->wisdom = newPlayer->b_wisdom + 1;
          newPlayer->charisma = newPlayer->b_charisma + 1;
        }

    // stat mods
    newPlayer->strMod = ((newPlayer->strength - 10) / 2);
    newPlayer->dexMod = ((newPlayer->dexterity - 10) / 2);
    newPlayer->conMod = ((newPlayer->constitution - 10) / 2);
    newPlayer->intMod = ((newPlayer->intelligence - 10) / 2);
    newPlayer->wisMod = ((newPlayer->wisdom - 10) / 2);
    newPlayer->chaMod = ((newPlayer->charisma - 10) / 2);

    // HP at first level
if (newPlayer->class == 1) {
  newPlayer->maxhp = (12 + newPlayer->conMod);
}

if (newPlayer->class == 2) {
  newPlayer->maxhp = (8 + newPlayer->conMod);
}

if (newPlayer->class == 3) {
  newPlayer->maxhp = (10 + newPlayer->conMod);
}

if (newPlayer->class == 4) {
  newPlayer->maxhp = (10 + newPlayer->conMod);
}

if (newPlayer->class == 5) {
  newPlayer->maxhp = (8 + newPlayer->conMod);
}

if (newPlayer->class == 6) {
  newPlayer->maxhp = (6 + newPlayer->conMod);
}

if (newPlayer->class == 7) {
  newPlayer->maxhp = (6 + newPlayer->conMod);
}

    // HP and higher levels
if (newPlayer->level > 1) {
  if (newPlayer->class == 1) {
    newPlayer->maxhp = ((7 + newPlayer->conMod) * newPlayer->level);
  }

  if (newPlayer->class == 2) {
    newPlayer->maxhp = ((5 + newPlayer->conMod) * newPlayer->level);
  }

  if (newPlayer->class == 3) {
    newPlayer->maxhp = ((6 + newPlayer->conMod) * newPlayer->level);
  }

  if (newPlayer->class == 4) {
    newPlayer->maxhp = ((6 + newPlayer->conMod) * newPlayer->level);
  }

  if (newPlayer->class == 5) {
    newPlayer->maxhp = ((5 + newPlayer->conMod) * newPlayer->level);
  }

  if (newPlayer->class == 6) {
    newPlayer->maxhp = ((4 + newPlayer->conMod) * newPlayer->level);
  }

  if (newPlayer->class == 7) {
    newPlayer->maxhp = ((4 + newPlayer->conMod) * newPlayer->level);
  }

}

  newPlayer->hp = newPlayer->maxhp;

  // Armor Class
  newPlayer->ac = (10 + newPlayer->dexMod)/* + armorBonus*/;

  // Barbarian's Unarmored Defense
  if (newPlayer->class == 1) {
    newPlayer->ac = ((10 + newPlayer->conMod) + newPlayer->dexMod);
  }

  mvprintw(newPlayer->position.y, newPlayer->position.x, "@");
  move(newPlayer->position.y, newPlayer->position.x);

  mvprintw(30, 1, "[                        ]");

  raw();
  start_color();
  init_pair(1,COLOR_BLACK, COLOR_GREEN);
  attron(COLOR_PAIR(1));

  if (newPlayer->class == 1) {
      mvprintw(30, 2, "     Rodney Barbarian   ");
  }

  if (newPlayer->class == 2) {
      mvprintw(30, 2, "    Rodney the Cleric   ");
  }

  if (newPlayer->class == 3) {
      mvprintw(30, 2, "   Rodney the Fighter   ");
  }

  if (newPlayer->class == 4) {
      mvprintw(30, 2, "   Rodney the Paladin   ");
  }

  if (newPlayer->class == 5) {
      mvprintw(30, 2, "    Rodney the Rogue    ");
  }

  if (newPlayer->class == 6) {
      mvprintw(30, 2, "    Rodney the Wizard   ");
  }

  if (newPlayer->class == 7) {
      mvprintw(30, 2, "   Rodney the Sorcerer  ");
  }


  attroff(COLOR_PAIR(1));

  mvprintw(30, 29, "STR: %d", newPlayer->strength);
  mvprintw(30, 36, "(%d)", newPlayer->strMod);
  mvprintw(30, 41, "DEX: %d", newPlayer->dexterity);
  mvprintw(30, 48, "(%d)", newPlayer->dexMod);
  mvprintw(30, 53, "CON: %d", newPlayer->constitution);
  mvprintw(30, 60, "(%d)", newPlayer->conMod);
  mvprintw(30, 65, "INT: %d", newPlayer->intelligence);
  mvprintw(30, 72, "(%d)", newPlayer->intMod);
  mvprintw(30, 77, "WIS: %d", newPlayer->wisdom);
  mvprintw(30, 84, "(%d)", newPlayer->wisMod);
  mvprintw(30, 89, "CHA: %d", newPlayer->charisma);
  mvprintw(30, 96, "(%d)", newPlayer->chaMod);

  mvprintw(31, 1, "HP: %d", newPlayer->hp);
  mvprintw(31, 7, "(%d)", newPlayer->maxhp);
  mvprintw(31, 13, "Level: %d", newPlayer->level);
  mvprintw(31, 23, "AC: %d", newPlayer->ac);

  mvprintw(31, 31, "Race: ");

  if (newPlayer->race == 1) {
      init_pair(2,COLOR_GREEN, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 37, "Orc");
      attroff(COLOR_PAIR(2));
    }

  if (newPlayer->race == 2) {
      init_pair(2,COLOR_YELLOW, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 37, "Dragonborn");
      attroff(COLOR_PAIR(2));
    }

  if (newPlayer->race == 3) {
      init_pair(2,COLOR_RED, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 37, "Dwarf");
      attroff(COLOR_PAIR(2));
    }

  if (newPlayer->race == 4) {
      init_pair(2,COLOR_CYAN, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 37, "Elf");
      attroff(COLOR_PAIR(2));
    }

  if (newPlayer->race == 5) {
      init_pair(2,COLOR_MAGENTA, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 37, "Gith");
      attroff(COLOR_PAIR(2));
    }

  if (newPlayer->race == 6) {
      init_pair(2,COLOR_BLUE, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 37, "Hobbit");
      attroff(COLOR_PAIR(2));
    }

  if (newPlayer->race == 7) {
      init_pair(2,COLOR_WHITE, COLOR_BLACK);
      attron(COLOR_PAIR(2));
      mvprintw(31, 37, "Human");
      attroff(COLOR_PAIR(2));
    }


  if (newPlayer->alignment == 0) {
      mvprintw(31, 51, "Neutral  ");
    }

  if (newPlayer->alignment == 1) {
      mvprintw(31, 51, "Chaotic  ");
    }

  if (newPlayer->alignment == 2) {
      mvprintw(31, 51, "Lawful  ");
    }


  return newPlayer;
}

Position * handleInput(int input, Player * user)
{
  Position * newPosition;
  newPosition = malloc(sizeof(Position));

  switch (input)
  {
    /* move up */
    case '8':
    case KEY_UP:
        newPosition->x = user->position.x;
        newPosition->y = user->position.y - 1;
        break;

    /* move down */
    case '2':
    case KEY_DOWN:
        newPosition->y = user->position.y + 1;
        newPosition->x = user->position.x;
        break;

    /* move left */
    case '4':
    case KEY_LEFT:
        newPosition->y = user->position.y;
        newPosition->x = user->position.x - 1;
        break;

    /* move right */
    case '6':
    case KEY_RIGHT:
        newPosition->y = user->position.y;
        newPosition->x = user->position.x + 1;
        break;

    /* diagonal up left */
    case '7':
        newPosition->y = user->position.y - 1;
        newPosition->x = user->position.x - 1;
        break;

    /* diagonal up right */
    case '9':
        newPosition->y = user->position.y - 1;
        newPosition->x = user->position.x + 1;
        break;

    /* diagonal down left */
    case '1':
        newPosition->y = user->position.y + 1;
        newPosition->x = user->position.x - 1;
        break;

    /* diaganol down right */
    case '3':
        newPosition->y = user->position.y + 1;
        newPosition->x = user->position.x + 1;
        break;

    default:
          break;
  }

  return newPosition;

}

/* check what is at next position */
int checkPosition(Position * newPosition, Player * user, char ** level)
{
    int space;
    switch (mvinch(newPosition->y, newPosition->x))
    {
        case '.':
        case '#':
        case '+':
            playerMove(newPosition, user, level);
            break;
        default:
            move(user->position.y, user->position.x);
            break;
    }
}

int playerMove(Position * newPosition, Player * user, char ** level)
{

    char buffer[8];



    sprintf(buffer, "%c", level[user->position.y][user->position.x]);

    mvprintw(user->position.y, user->position.x, buffer);

    user->position.y = newPosition->y;
    user->position.x = newPosition->x;

    mvprintw(user->position.y, user->position.x, "@");
    move(user->position.y, user->position.x);

}
