#include "rogue.h"

/* making rooms and the map */

int mapSetUp()
{

  mvprintw(5, 13, "-----------------------------------");
  mvprintw(6, 13, "|..............|...|..............|");
  mvprintw(7, 13, "|..............|...+..............|");
  mvprintw(8, 13, "|..............|...|..............|");
  mvprintw(9, 13, "|..............|...|..............|");
  mvprintw(10, 13, "|..............|...|..............|");
  mvprintw(11, 13, "-------+---------+-----------------");
  mvprintw(12, 13, "       ######    ##");

  mvprintw(10, 54, "---+--");
  mvprintw(11, 54, "|....|");
  mvprintw(12, 54, "|....|");
  mvprintw(13, 54, "------");

  mvprintw(13, 13, "----------");
  mvprintw(14, 13, "|........|  ###");
  mvprintw(15, 13, "|........| ####");
  mvprintw(16, 13, "|........| ###");
  mvprintw(17, 13, "|........| ###");
  mvprintw(18, 13, "|........| ####");
  mvprintw(19, 13, "-----+---- ###");
  mvprintw(20, 16, "  ########");

  mvprintw(15, 28, "---------");
  mvprintw(16, 28, "|....|..|");
  mvprintw(17, 28, "|....|..|");
  mvprintw(18, 28, "+....|..|");
  mvprintw(19, 28, "|.......|");
  mvprintw(20, 28, "|.......|");
  mvprintw(21, 28, "---------");

  mvprintw(7, 50, "   ####");
  mvprintw(8, 50, "  ######");
  mvprintw(9, 50, "########");
  mvprintw(10, 50, "##");
  mvprintw(11, 50, "#");
  mvprintw(12, 50, "#");
  mvprintw(13, 26, "########################");

}

char ** saveLevelPositions()
{
    int x, y;
    char ** positions;
    positions = malloc(sizeof(char *) * 25);

    for (y = 0; y < 25; y++)
    {
        positions[y] = malloc(sizeof(char) * 100);

        for (x = 0; x < 100; x++)
        {
            positions[y][x] = mvinch(y, x);
        }
    }

    return positions;
}
